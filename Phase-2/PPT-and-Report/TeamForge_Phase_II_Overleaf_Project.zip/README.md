# TeamForge – Phase II Overleaf Project

Team **DSCPP-III-2026-T238** · Graphic Era (Deemed to be University), Dehradun

This single project contains two independent LaTeX documents:

| Folder | Main file | Produces |
|---|---|---|
| `PPT/` | `PPT/main.tex` | Phase II presentation – 15 slides, 16:9 (Beamer) |
| `PDF/` | `PDF/main.tex` | Phase II written report – 5 pages, A4 |

Each folder is self-contained: it has its own copy of the original logos
(`graphicera_logo.png`, `geulogo.png`) and an `assets/` folder with its images.

## Upload to Overleaf

1. Overleaf → **New Project → Upload Project** → choose `TeamForge_Phase_II_Overleaf_Project.zip`.
2. Open **Menu** (top left) and check **Compiler = pdfLaTeX** (the default).

## Switch between the two documents

Overleaf compiles one *Main document* at a time.

- **Presentation:** Menu → **Main document** → select `PPT/main.tex` → click **Recompile**.
- **Report:** Menu → **Main document** → select `PDF/main.tex` → click **Recompile**.

The first compile of the presentation may show "??" for the slide count
("2/??"); Overleaf reruns automatically and it becomes "2/15".

## Folder contents

```
PPT/
  main.tex                       presentation source
  graphicera_logo.png            original logo (used on every slide)
  geulogo.png                    original logo (copy, unused by the slides)
  assets/screenshot_entry.jpg            app screenshots, unaltered
  assets/screenshot_host_overview.jpg
  assets/screenshot_match_insights.jpg
PDF/
  main.tex                       report source
  geulogo.png                    original logo (page 1)
  graphicera_logo.png            original logo (copy)
  assets/member1_mukul.jpg ... member4_mehul.jpg   team photos
  assets/architecture_diagram_original.jpg          original diagram image (optional fallback)
```

## Editing notes

**Presentation (`PPT/main.tex`).** The slide size is 960 × 540 bp – the same
16:9 size as the final PDF – so every position is written in points from the
slide's top-left corner, e.g. `at (43.2,160.8)` means 43.2 bp from the left and
160.8 bp down. Text, tables, diagrams and the bar chart are all editable. Most
repeated items (team members, objectives, roadmap steps, bar values) are in
`\foreach` lists, so you edit one line per item. Bar lengths are computed from
the values automatically.

**Report (`PDF/main.tex`).** Answer boxes and tables grow automatically if you
add text. Bullets are ordinary `\item`s inside `tfbullets`. The architecture
diagram on page 2 is redrawn in TikZ; to use the original image instead,
replace the `tikzpicture` with the `\includegraphics` line given in the
comment just above it. The Team Member 2 photo is cropped in LaTeX
(`trim=0 54 0 115, clip`) exactly as in the final PDF; the image file itself is
unaltered.

**Fields kept as in the source.** The mentor *Interactions completed* field on
slide 2 is intentionally left blank. Test statuses are unchanged: the Qt Test
suite is "To be recorded", end-to-end testing is "In progress" and the strategy
comparison is "Pending".

## Fonts

Only standard TeX Live fonts are used, chosen for identical character widths
to the fonts in the final PDFs, so lines break in the same places:
Helvetica for Liberation Sans (slides), Times for Liberation Serif (report) and
Courier for Liberation Mono. Courier looks lighter than Liberation Mono; that is
the main visible difference from the original PDFs.

## Verification

Both documents were compiled with pdfLaTeX (TeX Live 2023), both from inside
their own folder and from the project root, after extracting this ZIP into an
empty directory. Word positions were compared against the final PDFs: text sits
within about 3 bp of the original, line breaks match, and table rules and box
edges are within 1 bp.
